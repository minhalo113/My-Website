class EbayProvider {
    async searchProducts(keyword) {
        console.log("⚠️ Ebay Provider is not implemented yet.");
        return [];
    }
}

export default new EbayProvider();